#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
安装"图片转 PDF"右键菜单。

在资源管理器中选中一张或多张图片，右键即可转换为 PDF。

用法：
    双击 install.bat，或执行：python install.py

实现说明：
    - 仅写入当前用户注册表（HKCU），无需管理员权限。
    - MultiSelectModel=Player 让一次选中多张图片时，脚本只被调用一次，
      并收到全部图片路径作为参数。
    - AppliesTo=System.Kind:=picture 让菜单只在图片文件上出现。
"""

import os
import sys
import winreg

VERB_NAME = "ImageToPDF"
VERB_LABEL = "转换为 PDF"
SCRIPT_NAME = "img2pdf.py"


def find_pythonw():
    """返回 pythonw.exe 的完整路径（无控制台窗口，避免闪黑框）。"""
    exe = sys.executable
    dirpath = os.path.dirname(exe)
    for name in ("pythonw.exe", "python3w.exe", "pythonw3.exe"):
        candidate = os.path.join(dirpath, name)
        if os.path.isfile(candidate):
            return candidate
    # 找不到就用当前解释器（会闪一下控制台，但功能正常）
    return exe


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.join(script_dir, SCRIPT_NAME)

    if not os.path.isfile(script_path):
        print(f"[错误] 找不到转换脚本：{script_path}")
        return 1

    pythonw = find_pythonw()
    # 右键菜单实际执行的命令：pythonw.exe "D:\脚本\img2pdf.py" "%1"
    # %1 由资源管理器替换为选中的文件（多选时自动追加 %2 %3 ...）
    command = f'"{pythonw}" "{script_path}" "%1"'

    root = winreg.HKEY_CURRENT_USER
    verb_key = r"Software\Classes\*\shell\ImageToPDF"

    # 先删除旧键，保证干净（幂等安装）
    for sub in (verb_key + r"\command", verb_key):
        try:
            winreg.DeleteKey(root, sub)
        except OSError:
            pass

    key = winreg.CreateKey(root, verb_key)
    winreg.SetValueEx(key, "", 0, winreg.REG_SZ, VERB_LABEL)
    winreg.SetValueEx(key, "MultiSelectModel", 0, winreg.REG_SZ, "Player")
    winreg.SetValueEx(key, "AppliesTo", 0, winreg.REG_SZ, "System.Kind:=picture")
    winreg.CloseKey(key)

    cmd_key = winreg.CreateKey(root, verb_key + r"\command")
    winreg.SetValueEx(cmd_key, "", 0, winreg.REG_SZ, command)
    winreg.CloseKey(cmd_key)

    print("[完成] 右键菜单已安装。")
    print(f"  菜单名称: {VERB_LABEL}")
    print(f"  转换脚本: {script_path}")
    print(f"  解释器  : {pythonw}")
    print()
    print("使用方法：在资源管理器中选中一张或多张图片，")
    print("          右键 -> 显示更多选项 -> 转换为 PDF。")
    print("（Windows 11 中该菜单位于“显示更多选项”子菜单内）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
