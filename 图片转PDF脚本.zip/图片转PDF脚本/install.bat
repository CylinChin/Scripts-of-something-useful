@echo off
rem 安装"图片转 PDF"右键菜单（双击本文件即可）
py "%~dp0install.py" 2>nul || python "%~dp0install.py"
echo.
pause
