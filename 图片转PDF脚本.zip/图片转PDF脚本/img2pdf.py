#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图片转 PDF

把选中的一张或多张图片合并/转换为一个 PDF，保存到图片所在目录。

用法：
    python img2pdf.py "图片1.jpg" "图片2.png" ...

说明：
    - 输出 PDF 以第一张图片（按文件名自然排序）命名，例如选中 scan1~scan10.jpg
      会生成 scan1.pdf，页码顺序为 1..10（自然排序，scan2 在 scan10 之前）。
    - 若同名 PDF 已存在，自动追加 (1)、(2) 以避免覆盖。
    - 通过 pythonw.exe 调用时无控制台窗口，改用弹窗提示结果。
"""

import os
import re
import sys

from PIL import Image, ImageOps

# 支持的图片扩展名
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff", ".webp"}


def natural_key(path):
    """自然排序键，让 scan2 排在 scan10 之前。"""
    name = os.path.basename(path)
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name)]


def load_rgb_image(path):
    """打开图片，修正 EXIF 方向，并统一为白底 RGB（处理透明通道）。"""
    img = Image.open(path)
    img = ImageOps.exif_transpose(img)
    if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
        rgba = img.convert("RGBA")
        background = Image.new("RGB", rgba.size, (255, 255, 255))
        background.paste(rgba, mask=rgba.split()[3])
        return background
    return img.convert("RGB")


def report(title, message, error=False):
    """有控制台则打印；无控制台（pythonw）则弹窗提示。"""
    message = str(message)
    if sys.stdout is not None and getattr(sys.stdout, "isatty", lambda: False)():
        print(message)
        return
    try:
        import ctypes
        icon = 0x10 if error else 0x40  # MB_ICONERROR / MB_ICONINFORMATION
        ctypes.windll.user32.MessageBoxW(0, message, title, icon)
    except Exception:
        pass


def main():
    if len(sys.argv) < 2:
        report("图片转 PDF", "请把要转换的图片路径作为参数传入。", error=True)
        return 1

    # 过滤出有效的图片文件
    images = []
    for arg in sys.argv[1:]:
        if os.path.isfile(arg) and os.path.splitext(arg)[1].lower() in IMAGE_EXTS:
            images.append(os.path.abspath(arg))

    if not images:
        report("图片转 PDF", "没有找到有效的图片文件（支持 jpg/png/bmp/gif/tif/webp）。", error=True)
        return 1

    # 按文件名自然排序，保证页码顺序稳定
    images.sort(key=natural_key)

    first = images[0]
    out_dir = os.path.dirname(first)
    base = os.path.splitext(os.path.basename(first))[0]
    out_path = os.path.join(out_dir, base + ".pdf")

    # 避免覆盖已有文件
    n = 1
    while os.path.exists(out_path):
        out_path = os.path.join(out_dir, f"{base} ({n}).pdf")
        n += 1

    # 逐个加载，跳过无法读取的图片
    pages = []
    for path in images:
        try:
            pages.append(load_rgb_image(path))
        except Exception as exc:
            report("图片转 PDF", f"跳过无法读取的图片：\n{path}\n{exc}", error=True)

    if not pages:
        report("图片转 PDF", "所有图片都处理失败，未生成 PDF。", error=True)
        return 1

    try:
        pages[0].save(out_path, "PDF", save_all=True, append_images=pages[1:])
    except Exception as exc:
        report("图片转 PDF", f"生成 PDF 失败：\n{exc}", error=True)
        return 1

    report("图片转 PDF", f"已生成 PDF：\n{out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
