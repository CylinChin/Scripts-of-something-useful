#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""卸载"图片转 PDF"右键菜单。"""

import sys
import winreg

VERB_KEY = r"Software\Classes\*\shell\ImageToPDF"


def main():
    root = winreg.HKEY_CURRENT_USER
    for sub in (VERB_KEY + r"\command", VERB_KEY):
        try:
            winreg.DeleteKey(root, sub)
        except OSError:
            pass

    try:
        winreg.OpenKey(root, VERB_KEY)
        print("卸载失败：菜单项仍然存在。")
        return 1
    except OSError:
        print("[完成] 已卸载“图片转 PDF”右键菜单。")
        return 0


if __name__ == "__main__":
    sys.exit(main())
