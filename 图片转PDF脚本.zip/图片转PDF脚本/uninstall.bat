@echo off
rem 卸载"图片转 PDF"右键菜单（双击本文件即可）
py "%~dp0uninstall.py" 2>nul || python "%~dp0uninstall.py"
echo.
pause
